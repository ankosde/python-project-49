### Hexlet tests and linter status:
[![Actions Status](https://github.com/ankosde/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/ankosde/python-project-49/actions)


Asciinema brain_even_games - https://asciinema.org/a/PtoCM31aan8F0VnjaEzAqcgcI

Asciinema brain_calc_games -  https://asciinema.org/a/Am1EAxGknfSp6qembCaFt3aNJ
 
Asciinema brain_gcd_games and and example package installation - https://asciinema.org/a/ro6e7P2zriE4cacHI9Y7wep5O

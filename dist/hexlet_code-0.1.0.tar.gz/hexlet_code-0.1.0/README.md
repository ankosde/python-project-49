### Hexlet tests and linter status:
[![Actions Status](https://github.com/ankosde/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/ankosde/python-project-49/actions)


Asciinema - https://asciinema.org/a/08S4Mmmckt0ewh4TKq5qTmkk7 
